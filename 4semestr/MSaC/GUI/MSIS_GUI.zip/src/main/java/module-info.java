module com.example.lab1 {
    requires javafx.controls;
    requires javafx.fxml;

    exports com.example.lab1_gradle;
    opens com.example.lab1_gradle to javafx.fxml;
}