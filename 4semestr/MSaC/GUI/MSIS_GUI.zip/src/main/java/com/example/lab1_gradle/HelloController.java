package com.example.lab1_gradle;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private Button analyzeButton;
    @FXML
    private TableColumn<tableObject,String> operandColumn;
    @FXML
    private TableColumn<tableObject,String > operatorColumn;
    @FXML
    private TableColumn<tableObject,Integer> operandCountColumn;
    @FXML
    private TableColumn<tableObject,Integer> operatorCountColumn;
    @FXML
    private TextField programDictionary;
    @FXML
    private TextField programVolume;
    @FXML
    private TextField programLength;
    @FXML
    private TextField operandDictionary;
    @FXML
    private TextField operatorDictionary;
    @FXML
    private TextField operatorCount;
    @FXML
    private TextField operandCount;
    @FXML
    private Button loadButton;

    @FXML
    private TableView<tableObject> operandTable;

    @FXML
    private TableView<tableObject> operatorTable;

    @FXML
    private TextArea programText;

    @FXML
    protected void onOpenFIle() {
        FileChooser fOpen = new FileChooser();
        File file = fOpen.showOpenDialog(HelloApplication.stage);
        if (file != null) {
            try {
                BufferedReader br1 = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
                String s;
                StringBuilder sb = new StringBuilder();
                while ((s = br1.readLine()) != null) {
                    sb.append(s);
                    sb.append('\n');
                }
                br1.close();
                programText.setText(sb.toString());
            } catch (FileNotFoundException e) {

            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    @FXML
    protected  void analyzeClick(){
        Tokenizer tokenizer = new Tokenizer();
        tokenizer.init_tokens();
        String code = "";
        ArrayList<String> codeArr = new ArrayList<>();
        String text = programText.getText();
        int  index = 0;
        StringBuilder sb = new StringBuilder();
        for(int j = 0;j<text.length();j++)
        {
            sb.append(text.charAt(j));
        }
        if(sb.indexOf("/*")!=-1) {

            while (sb.indexOf("/*") != -1) {
                int startPos = sb.indexOf("/*");
                int endPos = sb.indexOf("*/");
               // sb.delete(startPos, endPos+1);

                for(int i = startPos;i<=endPos+1;i++)
                    sb.deleteCharAt(startPos);
            }
            text = sb.toString();
        }
        while(text.contains("\n")!=false)
        {
            index = text.indexOf("\n");
            codeArr.add(text.substring(0,index));
            text = new String(text.substring(index+1));
        };
        codeArr.add(text);
        for(int i =0;i<codeArr.size();i++)
        {
            tokenizer.tokenize(codeArr.get(i));
        }
        operandCount.setText(Integer.toString(tokenizer.operandCount));
        operatorCount.setText(Integer.toString(tokenizer.operatorCount));
        int programLengthInt = tokenizer.operandCount+tokenizer.operatorCount;
        programLength.setText(Integer.toString(programLengthInt));
        int uniqueOperators = 0;
        int uniqueOperands = 0;
        for(Token tok:tokenizer.tok)
        {
            if(tok.getFunc())
            {
                if(tok.getOperandCount() != 0) uniqueOperands++;
                if(tok.getOperatorCount() != 0) uniqueOperators++;
            }
            else
            {
                if((tok.isOperator() || tok.get_name()=="]" || tok.get_name()=="(") && tok.get_count()!=0 ) uniqueOperators++;
                else if( tok.isOperand() && tok.get_count()!=0) uniqueOperands++;
            }

        }
        int programDictionaryInt = uniqueOperands+uniqueOperators;
        operandDictionary.setText(Integer.toString(uniqueOperands));
        operatorDictionary.setText(Integer.toString(uniqueOperators));
        programDictionary.setText(Integer.toString(programDictionaryInt));
        programVolume.setText(Double.toString(programLengthInt* (Math.log(programDictionaryInt)/Math.log(2))));
        fillOperandTable(tokenizer.tok);
        fillOperatorTable(tokenizer.tok);
    }
    protected  void fillOperandTable(List<Token> tok){
        ArrayList<tableObject> tableObjects = new ArrayList<>();
        for(Token token:tok)
        {
                if (token.getFunc()) {
                    if (token.getOperandCount() != 0) {
                        tableObjects.add(new tableObject(token.get_name(),token.getOperandCount()));
                    }
                }else {
                    if(!token.notOpAndOp()) {
                        if (!token.isOperator() && token.get_count()!=0) {
                            tableObjects.add(new tableObject(token.get_name(), token.get_count()));
                        }
                    }
                }
        }
        operandCountColumn.setCellValueFactory(new PropertyValueFactory<tableObject,Integer>("count"));
        operandColumn.setCellValueFactory(new PropertyValueFactory<tableObject,String>("name"));
        ObservableList<tableObject> objects = FXCollections.observableArrayList(tableObjects);
        operandTable.setItems(objects);
    }
    protected  void fillOperatorTable(List<Token> tok){
        ArrayList<tableObject> tableObjects = new ArrayList<>();
        for(Token token:tok)
        {

                if (token.getFunc()) {
                    if (token.getOperatorCount() != 0) {
                        tableObjects.add(new tableObject(token.get_name(),token.getOperatorCount()));
                    }
                }else {
                    if(!token.notOpAndOp()) {
                        if (token.isOperator() && token.get_count()!=0) {
                            if(token.get_name()=="if")  tableObjects.add(new tableObject(token.get_type(), token.get_count()));
                            else  if(token.get_name()=="{") tableObjects.add(new tableObject("{}",token.get_count()));
                            else tableObjects.add(new tableObject(token.get_name(),token.get_count()));

                        }
                    }
                    else{
                        if((token.get_name()=="]" || token.get_name()=="(") && token.get_count()!=0)
                        {
                            tableObjects.add(new tableObject(token.get_type(), token.get_count()));
                        }
                    }
                }
        }
        operatorCountColumn.setCellValueFactory(new PropertyValueFactory<tableObject,Integer>("count"));
        operatorColumn.setCellValueFactory(new PropertyValueFactory<tableObject,String>("name"));
        ObservableList<tableObject> objects = FXCollections.observableArrayList(tableObjects);
        operatorTable.setItems(objects);

    }
    public class tableObject{
        private final SimpleStringProperty name;

        private final SimpleIntegerProperty count;
        tableObject(String name,int count)
        {
            this.name = new SimpleStringProperty(name);
            this.count = new SimpleIntegerProperty(count);
        }
        public String getName(){return  this.name.get();}
        public Integer getCount(){return  this.count.get();}
    }

}