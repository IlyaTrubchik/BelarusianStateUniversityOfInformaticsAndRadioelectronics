package com.example.lab1_gradle;

public class Token {
    private String name;
    private String type;

    private boolean isOperator;

    private boolean isOperand;
    private boolean isFunction = false;

    private int OperandCount = 0;

    private int OperatorCount = 0;
    private int count;

    public boolean notOpAndOp(){if(this.isOperator == false && this.isOperand == false) return true;else return false;}
    public void changeToOperand(){this.isOperand = true;}

    public void changeToOperator() {
        this.isOperator = true;
    }

    public boolean isOperand(){return  this.isOperand;}
    public boolean isOperator() {
        return this.isOperator;
    }
    public void decCount(){this.count--;}
    public int getOperatorCount() {
        return this.OperatorCount;
    }

    public int getOperandCount() {
        return this.OperandCount;
    }

    public void incOperator() {
        this.OperatorCount++;
    }

    public void incOperand() {
        this.OperandCount++;
    }

    public void changeFunction() {
        this.isFunction = true;
    }

    public boolean getFunc() {
        return this.isFunction;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public void set_type(String type) {
        this.type = type;
    }

    public String get_name() {
        return this.name;
    }

    public String get_type() {
        return this.type;
    }

    public int get_count() {
        return this.count;
    }

    public void inc_count() {
        this.count++;
    }

    Token(String name, String type, Boolean isOperator,Boolean isOperand) {
        this.name = name;
        this.type = type;
        this.count = 0;
        this.isOperator = isOperator;
        this.isOperand = isOperand;
    }
}
