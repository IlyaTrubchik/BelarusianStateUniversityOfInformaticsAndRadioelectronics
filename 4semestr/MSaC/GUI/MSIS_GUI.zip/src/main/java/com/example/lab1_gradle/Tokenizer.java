package com.example.lab1_gradle;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Tokenizer {


    public  List<Token> tok;

    public int operandCount = 0;


    public int operatorCount = 0;
    public Tokenizer(){
        this.tok = new ArrayList<>();
    }
    public  String tokenize(String code){
        boolean isFunctionInitialize = false;
        boolean isComment = false;
        boolean isInitialisation = false;
        Token curTk = null;
        Token lastCorrectToken=null;
        Token prevToken =null;
        Token prevPrevToken =null;
        char[] code_arr=code.toCharArray();
        String part="";
        String long_part="";
        String token_res="";
        Token initTk =null;
        int last_correct_pos=1;
        int curr_pos=0;
        while(!Objects.equals(code, "")){
            while(curTk==null&&curr_pos!=code.length()){
                part=part.concat(String.valueOf(code_arr[curr_pos]));
                //token search(with maximal munch)
                curTk=correct_token(part);

                if(curTk==null){
                  curTk=reg(part);
                }
                if ((curTk != null)){
                    if (curTk.get_name() == "\"") {
                        int i = curr_pos + 1;
                        StringBuilder result = new StringBuilder();
                        result.append("\"");
                        while (i < code_arr.length && code_arr[i] != '\"' ) {
                            result.append(code_arr[i]);
                            i++;
                        }
                        result.append("\"");
                        curr_pos = i+1;
                        curTk =new Token(result.toString(),"LITERAL",  false, true);
                        tok.add(curTk);
                    }
                    else {
                        long_part = part;
                        lastCorrectToken = curTk;
                        while (curTk != null && curr_pos + last_correct_pos < code_arr.length) {
                            part = long_part;
                            lastCorrectToken = curTk;
                            long_part = long_part.concat(String.valueOf(code_arr[curr_pos + last_correct_pos]));
                            curTk = correct_token(long_part);
                            if (curTk == null) {
                                curTk = reg(long_part);
                            }
                            last_correct_pos++;
                        }
                        curTk = lastCorrectToken;

                        if (last_correct_pos == 1) {
                            curr_pos++;
                        } else {
                            curr_pos += last_correct_pos - 1;
                        }
                        if(curTk.get_name()=="//") {
                            curTk = null;
                            curr_pos = code.length();
                            isComment =true;
                        }
                    }
                }
                else{
                    curr_pos++;
                }

            }
            //add tokens to result string
            if(curTk!=null){
             //   token_res=token_res.concat(" "+curTk.get_type()+" ");
                if(tok.contains(curTk)){
                    //tok.get(tok.indexOf(curTk)).inc_count();
                    if (prevToken != null && curTk.get_type() == "ID" && (prevToken.get_type() == "LET" || prevToken.get_type() == "VAR")) {
                        initTk = curTk;
                        isInitialisation = true;
                    }
                    else {

                        if (prevToken != null && (curTk.get_name() == "(" && prevToken.get_type() == "ID" && !tok.get(tok.indexOf(prevToken)).getFunc())) {
                            isFunctionInitialize = true;
                            tok.get(tok.indexOf(prevToken)).changeFunction();
                            if (prevPrevToken == null) {
                                tok.get(tok.indexOf(prevToken)).incOperator();
                            } else {
                                tok.get(tok.indexOf(prevToken)).incOperand();
                                tok.get(tok.indexOf(prevToken)).incOperator();
                            }
                        } else {
                            if (curTk.getFunc()) {
                                if (prevToken == null) {
                                    tok.get(tok.indexOf(curTk)).incOperator();
                                    operatorCount++;
                                } else {
                                    tok.get(tok.indexOf(curTk)).incOperand();
                                    operandCount++;
                                    tok.get(tok.indexOf(curTk)).incOperator();
                                    operatorCount++;
                                }
                            } else if (curTk.notOpAndOp()) {
                                if (curTk.get_name() == "]" && prevToken.get_name() != "[") {
                                    tok.get(tok.indexOf(curTk)).inc_count();
                                    operatorCount++;
                                } else if (curTk.get_name() == "(" && !prevToken.getFunc()) {
                                    tok.get(tok.indexOf(curTk)).inc_count();
                                    operatorCount++;
                                }
                            } else {
                                if (tok.get(tok.indexOf(curTk)).isOperator()) {
                                    operatorCount++;
                                    tok.get(tok.indexOf(curTk)).inc_count();
                                    if (curTk.get_name() == "=" && isInitialisation) {
                                        tok.get(tok.indexOf(initTk)).inc_count();
                                        operandCount++;
                                    }
                                } else {
                                    if (prevToken != null && prevToken.get_type() != "LET" && prevToken.get_type() != "VAR" && !isFunctionInitialize) {
                                        operandCount++;
                                        tok.get(tok.indexOf(curTk)).inc_count();
                                    } else if (prevToken == null) {
                                        operandCount++;
                                        tok.get(tok.indexOf(curTk)).inc_count();
                                    }
                                }
                            }
                        }
                    }
                }
                else {
                    tok.add(curTk);
                    if( prevToken!=null && (prevToken.get_type() =="FUNC" && curTk.get_type()=="ID")) {
                       tok.get(tok.indexOf(curTk)).changeFunction();
                       isFunctionInitialize =true;
                    }
                    else {
                            if (tok.get(tok.indexOf(curTk)).isOperator()) {
                                operatorCount++;
                            } else if(!isFunctionInitialize) {
                                operandCount++;
                                tok.get(tok.indexOf(curTk)).inc_count();
                            }
                        if (prevToken != null && curTk.get_type() == "ID" && (prevToken.get_type() == "LET" || prevToken.get_type() == "VAR")) {
                            operandCount--;
                            tok.get(tok.indexOf(curTk)).decCount();
                            isInitialisation = true;
                            initTk =curTk;
                        }
                    }
                    //tok.get(tok.indexOf(curTk)).inc_count();
                    //tok.get(tok.indexOf(curTk)).incOperator();
                }
                prevPrevToken = prevToken;
                prevToken = curTk;
            }
            else if(!isComment){
                token_res=token_res.concat(String.valueOf(part.charAt(0)));
                curr_pos=0;
            }
            //cutting default string processed part
            if(curr_pos==0){
                code="";
                for(int i=curr_pos+1;i<code_arr.length;i++){
                    code=code.concat(String.valueOf(code_arr[i]));
                }
            }
            else{
                code="";
                for(int i=curr_pos;i<code_arr.length;i++){
                    code=code.concat(String.valueOf(code_arr[i]));
                }
            }


            code_arr=code.toCharArray();
            code=code.trim();
            curTk=null;
            lastCorrectToken = null;
            curr_pos=0;
            last_correct_pos=1;
            part="";
            long_part="";
        }
        return token_res;
    }
    public  Token correct_token(String part){
        for (Token token : tok) {
            if (Objects.equals(token.get_name(), part)) {
                return token;
            }
        }
        return null;
    }
    public  Token reg(String part){

        if(part.replaceAll("\\d+(\\.\\d*)?","NUM").equals("NUM")) {
            part = part.trim();
            Token ret = new Token(part, "NUM",false,true);
            tok.add(ret);
            return ret;
        }
        else{
            if(part.replaceAll("^([a-zA-Z_$][a-zA-Z\\d_$]*)$", "ID").equals("ID")){
                part=part.trim();
                Token ret = new Token(part,"ID",false,true);
                return ret;
            }
        }
        return null;

    }
    public  void init_tokens(){
        //logical
        tok.add(new Token("&&","LOGIC",true,false));
        tok.add(new Token("||","LOGIC",true,false));
        tok.add(new Token("!","LOGIC",true,false));
        //bitwise
        tok.add(new Token("&","BIT",true,false));
        tok.add(new Token("|","BIT",true,false));
        tok.add(new Token("^","BIT",true,false));
        tok.add(new Token("~","BIT",true,false));
        tok.add(new Token(">>","BIT",true,false));
        tok.add(new Token("<<","BIT",true,false));
        tok.add(new Token(">>>","BIT",true,false));
        //compare
        tok.add(new Token(">","COMP",true,false));
        tok.add(new Token("<","COMP",true,false));
        tok.add(new Token("<=","COMP",true,false));
        tok.add(new Token(">=","COMP",true,false));
        tok.add(new Token("==","COMP",true,false));
        tok.add(new Token("===","COMP",true,false));
        tok.add(new Token("!=","COMP",true,false));
        tok.add(new Token("!==","COMP",true,false));
        //arithmetic
        tok.add(new Token("+","PLUS",true,false));
        tok.add(new Token("-","MINUS",true,false));
        tok.add(new Token("/","DIV",true,false));
        tok.add(new Token("*","MULT",true,false));
        tok.add(new Token("%","MOD",true,false));
        tok.add(new Token("++","INC",true,false));
        tok.add(new Token("--","DEC",true,false));
        //keywords
        tok.add(new Token("for","FOR",true,false));
        tok.add(new Token("while","WHILE",true,false));
        tok.add(new Token("if","IF...ELSE",true,false));
        tok.add(new Token("do","DO",false,false));///add
        tok.add(new Token("switch","SWITCH",true,false));//addd
        tok.add(new Token("case","CASE",false,false));//add
        tok.add(new Token("else","ELSE",false,false));
        tok.add(new Token("function","FUNC",false,false));
        tok.add(new Token("var","VAR",false,false));
        tok.add(new Token("let","LET",false,false));
        tok.add(new Token("const","CONST",false,false));
        tok.add(new Token("class","CLASS",false,false));
        tok.add(new Token("continue","CONTINUE",true,false));
        tok.add(new Token("break","BREAK",true, false));
        //brackets
        tok.add(new Token("{","FIG_BRACK_OPEN",true,false));
        tok.add(new Token("}","FIG_BRACK_CLOSE",false,false));
        tok.add(new Token("(","()",false,false));
        tok.add(new Token(")","BRACK_CLOSE",false,false));
        tok.add(new Token("[","SQR_BRACK_OPEN",false,false));
        tok.add(new Token("]","[]",false,false));
        //assigment
        tok.add(new Token("=","ASSIGN",true,false));
        tok.add(new Token("+=","ASSIGN",true,false));
        tok.add(new Token("-=","ASSIGN",true,false));
        tok.add(new Token("*=","ASSIGN",true,false));
        tok.add(new Token("/=","ASSIGN",true,false));
        tok.add(new Token("%=","ASSIGN",true,false));
        tok.add(new Token("&=","ASSIGN",true,false));
        tok.add(new Token("|=","ASSIGN",true,false));
        tok.add(new Token("^=","ASSIGN",true,false));
        tok.add(new Token("~=","ASSIGN",true,false));
        tok.add(new Token("<<=","ASSIGN",true,false));
        tok.add(new Token(">>=","ASSIGN",true,false));
        tok.add(new Token(">>>=","ASSIGN",true,false));
        //operators
        tok.add(new Token(";","DOT_COM",true,false));
        tok.add(new Token("return","RETURN",true,false));
        tok.add(new Token(".","DOT",true,false));
        tok.add(new Token(",","COM",true,false));
        tok.add(new Token(":","D_COM",true,false));
        tok.add(new Token("?:","QUES_D_COM",false,false));
        //preprocess
        tok.add(new Token("\"","OPEN_LITER",false,false));
        tok.add(new Token("//","LINE_COMMENT",false,false));
        tok.add(new Token("/*","OPEN_COM_MUL",false,false));
        tok.add(new Token("*/","CLOSE_COM_MUL",false,false));
        //types
        tok.add(new Token("string","STR",false,false));
        tok.add(new Token("number","NUMB",false,false));
        tok.add(new Token("boolean","BOOL",false,false));
        tok.add(new Token("void","VOID",false,false));
        tok.add(new Token("null","NULL",false,false));
        tok.add(new Token("undefined","UND",false,false));
    }
}
